# my_answer = input("What is your answer? ")
# options = ["rock", "paper", "scissors"]

# if my_answer in options:
#     print("That option is a viable option")
# else:
#     print("Wrong answer try again")

key = "name"
person = {
    "name": "Kalob",
    "profession": "Coding teacher",
}

if key in person:
    print("Name is a valid dictionary key in the person object")

