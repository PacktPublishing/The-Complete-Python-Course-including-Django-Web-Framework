with open('readme.txt', 'r') as file:
    content = file.read()

print("The content is", content)
