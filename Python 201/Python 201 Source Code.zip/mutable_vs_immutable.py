string = "The fox jumped over the cow"
string = "Overwritten"
print(string.upper())
print(string)

names = ["Kalob", "Jacob", "Gully", "Amanda"]
names.append("Rhubarb")
print(names)
