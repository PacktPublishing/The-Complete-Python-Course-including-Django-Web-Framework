my_thing = False
if not my_thing:
    print("Print a statement in here")


name = "Kane Ezki"
if name not in ['Kalob', 'Jon', 'Gully']:
    print("Kane is not part of the club")
