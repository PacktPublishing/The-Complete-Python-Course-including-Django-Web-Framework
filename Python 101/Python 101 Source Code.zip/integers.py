items = 4  # Integer
price = 19.97  # Float
total = items * price  # Multiplication
print(total)

print(1_000_000_000_000)
