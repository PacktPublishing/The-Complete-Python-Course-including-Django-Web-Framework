
course = "Python 101"
twitter = "@KalobTaulien"

if course == "Python 101":
    # Our code can go in here
    if something:
        # do something else
        if somethingelse:
            # do another thing
        # write more stuff in here
    # Do more stuff in here

if course == "Python 101":
    # Our code can go in here
    pass
