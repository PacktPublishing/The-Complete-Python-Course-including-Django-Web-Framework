person = {
    "key": "value",
    "name": "Kalob",
    "twitter": "@KalobTaulien",
}
# print(person['twitter'])

print(person)
person['instagram'] = "@coding.for.everybody"
print(person)
del person['key']
print(person)

