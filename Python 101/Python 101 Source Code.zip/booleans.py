can_code = True

if can_code:
    print("You can code!")
