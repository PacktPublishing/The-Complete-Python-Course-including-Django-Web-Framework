name = "Kalob"
# welcome_message = "Hello {} welcome to Python 101".format(name)
welcome_message = f"Hello {name} welcome to Python 101"

print(welcome_message)
