foods = ('Pizza', 'Fish', 'Tomatoes',)
for food in foods:
    print("The food is", food)
