print("Hello world from Python 101")
