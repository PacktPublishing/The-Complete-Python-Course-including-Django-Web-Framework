num = 0

while num <= 100:
    print(num)
    num = num + 1
