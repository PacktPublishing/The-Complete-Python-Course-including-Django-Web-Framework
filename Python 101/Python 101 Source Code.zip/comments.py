# This is a code comment
name = "Kalob Taulien" # This is the teachers name
print(name)
