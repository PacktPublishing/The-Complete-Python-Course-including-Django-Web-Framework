lst = ["String", 1, 3.14, ["A new item"], "Kalob"]

# for item in lst:
#     print("The item is:", item)
