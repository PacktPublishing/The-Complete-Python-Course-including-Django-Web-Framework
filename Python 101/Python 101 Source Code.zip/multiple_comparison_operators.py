age = 31
name = "Jacob"

# if age >= 18 and name == "Kalob":
#     print("I can drink alcohol")
# else:
#     print("DONT DO ANYTHING")

if age >= 18 or name == "Kalob":
    print("I can drink alcohol")
else:
    print("DONT DO ANYTHING")
