
something = (,)

if something:
    print("This is true")
else:
    print("This is false")
