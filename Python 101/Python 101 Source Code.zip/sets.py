# lst = [varname, varname2, varname3]
# dictionary = {
#     "key": "value",
# }
s = {"Item 1", "Item 2", "Item 2", "Item 3"}
print(s)
