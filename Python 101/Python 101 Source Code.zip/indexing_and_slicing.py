lst = ['one', 'two', 'three', 'four', 'five']
#        0      1        2      3        4
print(lst[-2::])
# b = True
# print(b[0])

course = "Python 101"
print(course[5])
