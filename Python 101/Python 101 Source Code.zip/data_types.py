string = "A sentence"
integers = 99
floats = 3.14
list = ["Item 1", floats, integers]
tuple = ("Item 1", floats, integers)
sets = {"Item 1", "Item 2", "Item 3"}
dictionary = {
    "key": "value",
    "key2": "value2",
}
booleans = True # Or False
none = None
