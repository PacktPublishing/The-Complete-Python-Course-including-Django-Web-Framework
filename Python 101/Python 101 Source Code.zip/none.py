wallet = None

if wallet is None:
    print("Theres nothing in my wallet")
    wallet = 82.45

print("My wallet has ", wallet)
