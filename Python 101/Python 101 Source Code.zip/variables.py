
course = "Python 101"

print(course)
