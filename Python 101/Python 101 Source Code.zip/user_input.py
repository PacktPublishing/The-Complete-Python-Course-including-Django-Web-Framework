# age = input("What is your age? ")
# dog_years = int(age) * 7
# print(dog_years)

# name = input("What is your name? ")
# print("Hello,", name)
