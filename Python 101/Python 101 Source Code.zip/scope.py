name = "Kalob"

def myfunc(name):
    # name = "New name"
    return name

print(myfunc())
print(name)
