sentence = """A sentence in here

And on a new line"""
print(sentence.upper())
