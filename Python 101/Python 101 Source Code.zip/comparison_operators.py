# can_code = True

# if can_code == True:
#     # do a thing
#     print("You can code!")
# else:
#     # do something else
#     print("You dont know how to code yet")

# teacher = "Kalob Taulien"

# if teacher.lower() == "kalob taulien":
#     print("Show the teacher portal")
# else:
#     print("You are a student. Welcome to Python 101")

# name = input("What is your name? ")
# if name == "Bob":
#     print("Welcome Bob!")
#     bring_food = "Pizza"
# elif name == "Kalob":
#     print("Welcome to your teacher portal")
#     bring_food = "Tacos"
# elif name == "Nathan":
#     print("Welcome to the Gym")
#     bring_food = "Weigh protein"
# else:
#     print("You're not bob get outta here")
#     bring_food = "Salmon"

# print(f"You are eating {bring_food}")

# name = input("What is your name? ")
# name = name.lower()

# if name != "bob":
#     print("You're not bob, get out of here")
# else:
#     print("Welcome Bobby boy")

>
>=
<
<=
== is the same
!= is not the same

