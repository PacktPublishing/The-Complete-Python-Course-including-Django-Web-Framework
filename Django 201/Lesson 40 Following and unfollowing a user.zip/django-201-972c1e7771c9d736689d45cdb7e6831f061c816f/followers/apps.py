from django.apps import AppConfig


class FollowersConfig(AppConfig):
    name = 'followers'
