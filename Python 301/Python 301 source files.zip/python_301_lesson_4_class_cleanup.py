class Animal:
    fur_color = "Orange"

    def speak(self):
        print("Raawwwwrr")

    def eat(self):
        pass

    def chase(self):
        pass

tiger = Animal()
tiger.speak()
