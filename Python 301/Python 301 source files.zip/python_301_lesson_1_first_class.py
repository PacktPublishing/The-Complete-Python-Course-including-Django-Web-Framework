# This is the syntax
# class ThisIsAnAnimal:
#     pass

# animal = ThisIsAnAnimal()

# Example
class Animal:
    this_is_a_property = "Something"

the_animal = Animal()
print(the_animal.this_is_a_property)
