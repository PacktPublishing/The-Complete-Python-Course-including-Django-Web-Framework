# pipenv install --python 3.9
# pipenv shell
# pipenv install Django==3.*
# pipenv --rm
